from flask import Flask
import os

app = Flask(__name__)

@app.get("/")
def home():
    return "Hello from Lab 1!"

@app.get("/whoami")
def whoami():
 
    euid = os.geteuid() if hasattr(os, "geteuid") else -1
    return f"EUID={euid} (0 means root)\n"

@app.get("/secret-demo")
def secret_demo():
    present = "SECRET_VALUE" in os.environ
    return f"Secret present at runtime? {present}\n"

if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    app.run(host="0.0.0.0", port=port)